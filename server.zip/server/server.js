var express = require('express')
var app = express()

app.get('/api/cookieme', (req, res) => {

  var options = {
    maxAge: 1000 * 60 * 15, // would expire after 15 minutes
    httpOnly: true, // The cookie only accessible by the web server
    secure: true,
    sameSite: 'none'
}

  res.cookie('test-cookie-node', 'test-value-node', options)
  res.send('You were cooked!!!')
})

app.listen(5326, () => {
  console.log(`Example app listening at http://localhost:5326`)
})